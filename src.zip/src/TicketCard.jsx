import React from 'react';

function TicketCard({ ticket }) {
  return (
    <div className="ticket-card">
      <div className="ticket-header">
        <span className="ticket-id">{ticket.id}</span>
        <img className="user-avatar" src={ticket.userAvatar} alt="user avatar" />
      </div>
      <h3>{ticket.title}</h3>
      <div className="ticket-footer">
        <span className={`priority-indicator priority-${ticket.priority}`}>
          {/* Display priority level as an icon */}
        </span>
        <span className="feature-label">{ticket.featureType}</span>
      </div>
    </div>
  );
}

export default TicketCard;
