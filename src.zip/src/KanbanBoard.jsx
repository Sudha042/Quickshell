import React from 'react';
import TicketCard from './TicketCard';

// Function to group tickets dynamically based on grouping criteria
const groupTickets = (tickets, grouping) => {
  const groups = {};
  tickets.forEach((ticket) => {
    const groupKey = ticket[grouping]; // Group by dynamic key (status, user, or priority)
    if (!groups[groupKey]) {
      groups[groupKey] = [];
    }
    groups[groupKey].push(ticket);
  });
  return groups;
};

function KanbanBoard({ tickets, grouping, sorting }) {
  const groupedTickets = groupTickets(tickets, grouping);
  
  // Sorting logic based on sorting criteria
  Object.keys(groupedTickets).forEach((key) => {
    groupedTickets[key].sort((a, b) => {
      if (sorting === 'priority') {
        return b.priority - a.priority; // Sort by priority descending
      }
      if (sorting === 'title') {
        return a.title.localeCompare(b.title); // Sort by title alphabetically
      }
      return 0;
    });
  });

  return (
    <div className="kanban-board">
      {/* Iterate over the grouped tickets and display them in columns */}
      {Object.keys(groupedTickets).map((groupKey) => (
        <div key={groupKey} className="kanban-column">
          <h2>{groupKey}</h2>
          {groupedTickets[groupKey].map((ticket) => (
            <TicketCard key={ticket.id} ticket={ticket} />
          ))}
        </div>
      ))}
    </div>
  );
}

export default KanbanBoard;
