import React, { useState, useEffect } from 'react';
import KanbanBoard from './KanbanBoard';
import './Componant.css';


function App() {
    const [tickets, setTickets] = useState([]);
    const [grouping, setGrouping] = useState('status'); // Default grouping
    const [sorting, setSorting] = useState('priority'); // Default sorting
    const [dropdown, setdropdown]=useState(false);
  
    // Fetch tickets from the API when the component mounts
    useEffect(() => {
      fetch('https://api.quicksell.co/v1/internal/frontend-assignment')
        .then((response) => response.json())
        .then((data) => setTickets(data.tickets)); // Assume the API returns tickets array
    }, []);
  
    // Handlers for Grouping and Ordering
    const handleGroupingChange = (e) => {
      setGrouping(e.target.value);
    };

    const handledropdownChange = (e) => {
        setdropdown(!dropdown);
      };
  
    const handleSortingChange = (e) => {
      setSorting(e.target.value);
    };
  
    return (
      <div className="App">
        <header className="dropdown-container">
          <div>
            <button onClick={ handledropdownChange}>Display</button>
            {
                dropdown && (
                    <div className="dropdown" 
                        style={{position:'absolute',
                                backgroundColor: 'white' }}>
              <div className="dropdown-row">
                <div className="dropdown-grouping">
                  <label>Grouping</label>
                  <select value={grouping} onChange={handleGroupingChange}>
                    <option value="status">Status</option>
                    <option value="user">User</option>
                    <option value="priority">Priority</option>
                  </select>
                </div>
                <div className="dropdown-ordering">
                  <label>Ordering</label>
                  <select value={sorting} onChange={handleSortingChange}>
                    <option value="priority">Priority</option>
                    <option value="title">Title</option>
                  </select>
                </div>
              </div>
            </div>
                )
            }
            
          </div>
        </header>
  
        {/* Kanban Board Component */}
        <KanbanBoard tickets={tickets} grouping={grouping} sorting={sorting} />
      </div>
    );
  }
  
  export default App;