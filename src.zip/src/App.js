//import logo from './logo.svg';
//import './App.css';
import Componant from './Main';

function App() {
  return (
    <div className="App">
      {
      < Componant />
      }
    </div>
  );
}

export default App;
